import React, {useState} from 'react'
import PushNotificationIOS from '@react-native-community/push-notification-ios';
import {View, Text, SafeAreaView, StyleSheet, TouchableOpacity, KeyboardAvoidingView, Platform, Keyboard} from 'react-native';
import {useForm} from 'react-hook-form'
import ReminderCard from './Components/ReminderCard.js'

const ReminderScreen = ({navigation}) => {
    const {register, handleSubmit} = useForm()

    const [reminder, setReminder] = useState()
    const [reminderItems, setReminderItems] = useState([])

    return (
        <SafeAreaView>
            {/* <form onSubmit={handleSubmit((data) => {
            //    PushNotificationIOS.addNotificationRequest(
            //      {
            //         id: 0,
            //         fireDate: new Date(),
            //         title: data.reminderName,
            //         repeats: true,
            //         repeatsComponent: {
            //             day: true
            //         }
            //         // repeatInterval: `${data.reminderInterval} minutes`
            //     }),
                
            })}
                
            >
                <input {...register("reminderName", {required: true})} placeholder="Reminder Name"/>
                <input type="submit" />
                <ReminderCard 
                    title={'reminder 2'}
                />
            </form> */}
           
           <form onSubmit={handleSubmit((data) => {
               // add function tha runs on submit
                Keyboard.dismiss()
                setReminderItems([...reminderItems, reminder])
                setReminder(null)
                reminderItems.map((reminder, index) => {
                    return <ReminderCard key={index} text={data.reminderName} />
                })
            })}>
                
           <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"}>
                <input {...register("reminderName", {required: true})} placeholder="Reminder Name" onChange={reminder => setReminder(reminder)}/>
                <input type="submit" />
           </KeyboardAvoidingView>
        </form>  
            {
                reminderItems.map((reminder, index) => {
                    return <ReminderCard key={index} text={reminder} />
                })
            }
        </SafeAreaView>
    )
}

const styles = StyleSheet.create ({
    heading: {
        fontSize: 40,
        textAlign: "center",
        margin: 10
    },
    reminderCard: {
        display: "flex",
        flexDirection: "row",
        backgroundColor: "54AD5D",
        borderRadius: 40,
        width: 100,
        height: 100,
        margin: 10
    },
    button: {
        borderRadius: 50
    },
    regular: {
        color: "black"
    }
})

export default ReminderScreen