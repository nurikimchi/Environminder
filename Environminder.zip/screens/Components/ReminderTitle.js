import React from 'react'
import {View, Text} from 'react-native'

const ReminderTitle = [
    {
        title: "Avoid single-use plastics."
    },
    {
        title: "Check for any unused electricity."
    },
    {
        title: "Check for any wasted water."
    }
]

export default ReminderTitle