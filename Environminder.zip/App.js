// import { StatusBar } from 'expo-status-bar';
// import { NavigationContainer } from '@react-navigation/native';
// import { createNativeStackNavigator } from '@react-navigation/native-stack';
import React from 'react'
import { StyleSheet, Text, View, Image, SafeAreaView, TouchableHighlight, Button, Alert } from 'react-native';
// import WelcomeScreen from './screens/HomeScreen.js'
// import InformationScreen from './screens/InformationScreen.js'
import Navigator from './routes/homeStack.js'

export default function App() {
  return (
    <Navigator />
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'dodgerblue',
    alignItems: 'center',
    justifyContent: 'center'
  },
});

// export default function App() {
//   const handlePress = () => console.log("pressed!")
//   return (
//     <SafeAreaView style={styles.container}>
//       <Text numberOfLines = {1} onPress={handlePress}>Hello World!</Text>
//       <TouchableHighlight onPress = {() => console.log("Image tapped")}>
//         <Image  
//           source={{
//             width: 200,
//             height: 300,
//             uri: "https://picsum.photos/200/300"
//           }}
//         />
//       </TouchableHighlight>
//       <Button 
//         title = "Click me"
//         color = "black"
//         onPress={() => Alert.prompt("my title", "my message", text => console.log(text))}
//       />
//       <Button title="Submit" color = "black" onPress = {() => Alert.alert("My title", "my message", [
//         {text: "Yes", onPress: () => console.log("Yes")},
//         {text: "No", onPress: () => console.log("no")}
//       ])}/>
//       <StatusBar style="auto" />
//     </SafeAreaView>
//   );
// }